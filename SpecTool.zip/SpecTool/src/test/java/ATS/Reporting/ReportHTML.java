package ATS.Reporting;
import com.aventstack.extentreports.ExtentReporter;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class ReportHTML {
	public static ExtentReports report ;
	public static ExtentTest test;
	public static void ReportTrigger(){
		ExtentReporter htmlreporter = new ExtentHtmlReporter(System.getProperty("user.dir")+"\\target\\reports" + "\\Report" + ".htm");
		
		report = new ExtentReports();
		
		 report.setSystemInfo("ENVIRONMENT", "QA Env");
		 report.setSystemInfo("test type", "REGRESSION");
		 report.setSystemInfo("Technology", "Java");
		 report.setSystemInfo("Browser", "Chrome");
		
		report.attachReporter(htmlreporter);

		 test= report.createTest("Create a Project in ATS");
		 
		 test.assignCategory("Functional");
	
	}
}
