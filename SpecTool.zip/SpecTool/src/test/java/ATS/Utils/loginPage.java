package ATS.Utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import ATS.Reporting.ReportHTML;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;

public class loginPage {
	public static WebDriver driver;

@After
public void test(){
ReportHTML.report.flush();	
}
@Given("^user open the Ats Spec \"([^\"]*)\" URL$")
public void user_open_the_Ats_Spec_URL(String arg1) {
	System.setProperty("webdriver.chrome.driver","src/test/resources/chromedriver.exe");
	ReportHTML.ReportTrigger();
	driver = new ChromeDriver();
    driver.get("https://spec.atsspecsolutions.com/");
    
    Wait wait = new WebDriverWait(driver,30);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'LOG IN')]")));
    ReportHTML.test.log(Status.INFO, "User opened the ATS Spec tool");
}

@Given("^user loign to the application using \"([^\"]*)\" User Name and \"([^\"]*)\" PassWord$")
public void user_loign_to_the_application_using_User_Name_and_PassWord(String userName, String passWord) {
	driver.findElement(By.name("username")).sendKeys(userName);
	driver.findElement(By.name("password")).sendKeys(passWord);
    
	driver.findElement(By.xpath("//*[contains(text(),'Login')]")).click();
	ReportHTML.test.log(Status.INFO, "User login to the ATS Spec tool");    
}
}
