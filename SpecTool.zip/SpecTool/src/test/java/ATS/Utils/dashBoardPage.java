package ATS.Utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import ATS.Reporting.ReportHTML;
import cucumber.api.java.en.When;

public class dashBoardPage {
WebDriver driver = loginPage.driver;
@When("^user click on the New Project on the Start New Project Widget$")
public void user_click_on_the_New_Project_on_the_Start_New_Project_Widget() {
	Wait wait = new WebDriverWait(driver,30);
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a/span[contains(text(),'New Project')]")));
	
    driver.findElement(By.xpath("//a/span[contains(text(),'New Project')]")).click();
    ReportHTML.test.log(Status.INFO, "User click on the new project widget");
}
}
