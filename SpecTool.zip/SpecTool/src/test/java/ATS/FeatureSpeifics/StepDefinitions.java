package ATS.FeatureSpeifics;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import ATS.Reporting.ReportHTML;
import ATS.Utils.loginPage;
import cucumber.api.java.After;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinitions {
WebDriver driver = loginPage.driver;

@After
public void test(){
ReportHTML.report.flush();	
}
@When("^user enters the basic project details$")
public void user_enters_the_basic_project_details() throws InterruptedException {
	Thread.sleep(3000);
	
	List<WebElement> inputs=driver.findElements(By.xpath("//input")); 
	
    inputs.get(1).sendKeys("ATC-Demo");Thread.sleep(3000);
    inputs.get(2).sendKeys("Canada");Thread.sleep(3000);
    inputs.get(3).sendKeys("Ontario");Thread.sleep(3000);
    
    inputs.get(4).clear();
    inputs.get(4).sendKeys("To");Thread.sleep(3000);
    inputs.get(4).sendKeys("ro");Thread.sleep(3000);
    inputs.get(4).sendKeys("nto");Thread.sleep(3000);
    /*List<WebElement> cityName=driver.findElements(By.xpath("//*[contains(text(),'Toronto')]")); 
	cityName.get(0).click();*/
	
    inputs.get(5).sendKeys("2020-01-31");Thread.sleep(3000);
    inputs.get(6).sendKeys("2020");Thread.sleep(3000);
    
    driver.findElement(By.xpath("//button//span[contains(text(),'Next')]")).click();; 
    ReportHTML.test.log(Status.INFO, "User enters the basic project details");
}

@When("^user chooses the applicable building classes \"([^\"]*)\"$")
public void user_chooses_the_applicable_building_classes(String classes) throws InterruptedException {
	Thread.sleep(3000);
	  WebElement chkBoxMulti = driver.findElement(By.xpath("//*[contains(text(),'Multi-use')]"));
	  JavascriptExecutor js = (JavascriptExecutor)driver;
	js.executeScript("arguments[0].click();", chkBoxMulti); Thread.sleep(3000); 
		
    String[] multiClass = classes.split(";");WebElement clsDesired ;
    for (int i = 0; i < multiClass.length; i++) {
    	String className = multiClass[i]; 
    	System.out.println("Class"+className);

    	switch (className) {
    	case "Commercial":
   		 clsDesired = driver.findElement(By.xpath("//*[starts-with(text(),'Commercial')]"));
   		js.executeScript("arguments[0].click();", clsDesired); 
    		break;
    	case "Hospitality":
    		System.out.println("Hospitality");
   		    clsDesired = driver.findElement(By.xpath("//*[starts-with(text(),'Hospitality')]"));
   		 js.executeScript("arguments[0].click();", clsDesired);
    		break;
    	case "Light Commercial":
		    clsDesired = driver.findElement(By.xpath("//*[starts-with(text(),'Light Commercial')]"));
		    js.executeScript("arguments[0].click();", clsDesired);
    		break;
    	case "Office Buildings":
    		    clsDesired = driver.findElement(By.xpath("//*[starts-with(text(),'Office Buildings')]"));
    		    js.executeScript("arguments[0].click();", clsDesired);
    		break;
    	case "Public Space":
		    clsDesired = driver.findElement(By.xpath("//*[starts-with(text(),'Public Space')]"));
		    js.executeScript("arguments[0].click();", clsDesired);
    		break;
    	case "Recreational Facilities":
		    clsDesired = driver.findElement(By.xpath("//*[starts-with(text(),'Recreational Facilities')]"));
		    js.executeScript("arguments[0].click();", clsDesired);
    		break;
    	case "Residential":
    		System.out.println("Residential");
		    clsDesired = driver.findElement(By.xpath("//*[starts-with(text(),'Residential')]"));
		    js.executeScript("arguments[0].click();", clsDesired);
    		break;
    	default:
    		break;
    	}
	}
    ReportHTML.test.log(Status.INFO, "User chooses the applicable building classes ");
}

@When("^user selects a building type \"([^\"]*)\"$")
public void user_selects_a_building_type(String buildTypes) {
	  WebElement chkBoxMulti = driver.findElement(By.xpath("//*[contains(text(),'Multi-use')]"));
	  JavascriptExecutor js = (JavascriptExecutor)driver;
		
  String[] multiBuilds = buildTypes.split(";");WebElement buildDesired ;
  for (int i = 0; i < multiBuilds.length; i++) {
  	String className = multiBuilds[i]; 
  	System.out.println("Build\t"+ className);
  	switch (className) {
  	case "Bank":
 		 buildDesired = driver.findElement(By.xpath("//*[starts-with(text(),'Bank')]"));
 		js.executeScript("arguments[0].click();", buildDesired); 
  		break;
  	case "Bar":
  		System.out.println("Bar / Restaurant");
 		    buildDesired = driver.findElement(By.xpath("//*[starts-with(text(),'Bar / Restaurant')]"));
 		 js.executeScript("arguments[0].click();", buildDesired);
  		break;
  	case "Dealership":
		    buildDesired = driver.findElement(By.xpath("//*[starts-with(text(),'Dealership / Service Center')]"));
		    js.executeScript("arguments[0].click();", buildDesired);
  		break;
  	case "Gas Station":
  		    buildDesired = driver.findElement(By.xpath("//*[starts-with(text(),'Gas Station')]"));
  		    js.executeScript("arguments[0].click();", buildDesired);
  		break;
  	case "Hair Salon":
		    buildDesired = driver.findElement(By.xpath("//*[starts-with(text(),'Hair Salon')]"));
		    js.executeScript("arguments[0].click();", buildDesired);
  		break;
  	case "Retail":
  		System.out.println("Retail");
		    buildDesired = driver.findElement(By.xpath("//*[starts-with(text(),'Retail')]"));
		    js.executeScript("arguments[0].click();", buildDesired);
  		break;
  	default:
  		System.out.println(className);
	    buildDesired = driver.findElement(By.xpath("//*[starts-with(text(),'"+className+"')]"));
	    js.executeScript("arguments[0].click();", buildDesired);
  		break;
  	}
  	
	}

  driver.findElement(By.xpath("//button//span[contains(text(),'Next')]")).click();;
  ReportHTML.test.log(Status.INFO, "User chooses the building type ");
    
}

@When("^user adds the collaborators to the project$")
public void user_adds_the_collaborators_to_the_project() {
	  JavascriptExecutor js = (JavascriptExecutor)driver;
	List<WebElement> collaborators = driver.findElements(By.xpath("//input[contains(@value,'view-only')]"));
	for (int i = 0; i < collaborators.size(); i++) {
		js.executeScript("arguments[0].click();", collaborators.get(i));
	}
		 
}

@When("^user click on the Finish button$")
public void user_click_on_the_Finish_button() throws InterruptedException {
    Thread.sleep(4000);
    driver.findElement(By.xpath("//span[contains(text(),'Finish')]")).click();
    ReportHTML.test.log(Status.INFO, "User click on the finish button");
    
}

@Then("^the user validates the project creation$")
public void the_user_validates_the_project_creation() throws InterruptedException {
	Thread.sleep(5000);
    WebElement product = driver.findElement(By.xpath("//*[contains(text(),'Product Selection')]"));
    if(product.isDisplayed()){
    	System.out.println("Project created successfully");
    	ReportHTML.test.log(Status.INFO, "Project created successfully");
    	driver.close();
    	  
    }else{
    	ReportHTML.test.log(Status.FAIL, "User failed to create the project");
    	  driver.close();
    	Assert.fail();
    }
}


}
